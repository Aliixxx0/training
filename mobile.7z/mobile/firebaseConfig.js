import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithEmailAndPassword } from 'firebase/auth';
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyBl6awDV1UgmLLOdFyX2qcW5KG8VvWpaI0",
  authDomain: "jaicome-1bf99.firebaseapp.com",
  projectId: "jaicome-1bf99",
  storageBucket: "jaicome-1bf99.firebasestorage.app",
  messagingSenderId: "449731840538",
  appId: "1:449731840538:web:8890c9dfb55fe08c331fa3",
  measurementId: "G-GLM0ZZP97L",
  databaseURL: "https://jaicome-1bf99-default-rtdb.firebaseio.com"
};

// Initialize Firebase
console.log('Initializing Firebase with config:', firebaseConfig);

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const database = getDatabase(app); // for Realtime DB

console.log('Firebase initialized successfully');
console.log('Auth instance:', auth ? 'Created' : 'Failed');
console.log('Database instance:', database ? 'Created' : 'Failed');

// Test function to verify auth is working
const testAuth = async (email, password) => {
  try {
    const result = await signInWithEmailAndPassword(auth, email, password);
    console.log('Test auth successful:', result.user.uid);
    return { success: true, user: result.user };
  } catch (error) {
    console.error('Test auth failed:', error);
    return { success: false, error };
  }
};

export { app, auth, provider, database, testAuth };
