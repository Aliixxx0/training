import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar, View, Text, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet, Alert, ScrollView, SafeAreaView, KeyboardAvoidingView, Platform, FlatList } from 'react-native';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { ref, set } from 'firebase/database';
import { auth, database } from './firebaseConfig';

// Create navigation stack
const Stack = createStackNavigator();

// Admin email (same as web app)
const ADMIN_EMAIL = "admin@training.com";

// Login Screen Component
function LoginScreen({ navigation }) {
  const [data, setData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  const handleInputChange = (name, value) => {
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleLogin = async () => {
    if (!data.email || !data.password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, data.email, data.password);
      // Navigation will be handled by the auth state listener
    } catch (err) {
      const errorMessage = err?.message || 'An unknown error occurred';
      Alert.alert('Login Failed', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!data.email || !data.password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      const user = userCredential.user;
      
      // Save user data to database
      await set(ref(database, 'users/' + user.uid), {
        email: user.email,
        uid: user.uid,
      });
      
    } catch (err) {
      const errorMessage = err?.message || 'An unknown error occurred';
      Alert.alert('Signup Failed', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.loginCard}>
          <Text style={styles.title}>Training.com</Text>
          <Text style={styles.subtitle}>{isLogin ? 'Login' : 'Sign Up'}</Text>
          
          <View style={styles.formGroup}>
            <TextInput
              placeholder="Email"
              value={data.email}
              onChangeText={(text) => handleInputChange('email', text)}
              style={styles.input}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
          
          <View style={styles.formGroup}>
            <TextInput
              placeholder="Password"
              value={data.password}
              onChangeText={(text) => handleInputChange('password', text)}
              style={styles.input}
              secureTextEntry
            />
          </View>
          
          <View style={styles.buttonGroup}>
            {isLogin ? (
              <TouchableOpacity 
                style={styles.primaryButton} 
                onPress={handleLogin}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Login</Text>
                )}
              </TouchableOpacity>
            ) : (
              <TouchableOpacity 
                style={styles.primaryButton} 
                onPress={handleSignup}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Sign Up</Text>
                )}
              </TouchableOpacity>
            )}
          </View>
          
          <TouchableOpacity 
            style={styles.toggleButton} 
            onPress={() => setIsLogin(!isLogin)}
          >
            <Text style={styles.toggleText}>
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// Dashboard Screen Component
function DashboardScreen({ route, navigation, user }) {
  const [loading, setLoading] = useState(false);
  
  // Dummy training data - same as web app
  const trainingCourses = [
    { id: '1', title: 'Introduction to Web Development', duration: '4 weeks', level: 'Beginner', enrolled: true },
    { id: '2', title: 'JavaScript Fundamentals', duration: '6 weeks', level: 'Beginner', enrolled: true },
    { id: '3', title: 'React Basics', duration: '8 weeks', level: 'Intermediate', enrolled: false },
    { id: '4', title: 'Advanced CSS Techniques', duration: '3 weeks', level: 'Intermediate', enrolled: false },
    { id: '5', title: 'Backend Development with Node.js', duration: '10 weeks', level: 'Advanced', enrolled: false }
  ];

  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      // Navigation will be handled by the auth state listener
    } catch (error) {
      const errorMessage = error?.message || 'An unknown error occurred';
      Alert.alert('Logout Failed', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const renderCourseItem = ({ item }) => (
    <View style={styles.courseCard}>
      <Text style={styles.courseTitle}>{item.title}</Text>
      <Text style={styles.courseDetail}>Duration: {item.duration}</Text>
      <Text style={styles.courseDetail}>Level: {item.level}</Text>
      <TouchableOpacity 
        style={styles.courseButton}
        onPress={() => Alert.alert('Coming Soon', 'This feature will be available in the next update.')}
      >
        <Text style={styles.courseButtonText}>
          {item.enrolled ? 'Continue Learning' : 'Join Now'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#4285F4" barStyle="light-content" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Training.com</Text>
        <View style={styles.userInfo}>
          <Text style={styles.welcomeText}>
            Welcome, {user?.displayName || user?.email || 'User'}
          </Text>
          <TouchableOpacity 
            style={styles.logoutButton} 
            onPress={handleLogout}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.logoutText}>Logout</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>My Training Dashboard</Text>
        
        <View style={styles.section}>
          <Text style={styles.sectionSubtitle}>My Enrolled Courses</Text>
          <FlatList
            data={trainingCourses.filter(course => course.enrolled)}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No enrolled courses found.</Text>
            }
          />
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionSubtitle}>Available Courses</Text>
          <FlatList
            data={trainingCourses.filter(course => !course.enrolled)}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No available courses found.</Text>
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

// Main App Component
export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Check if user is admin
        setIsAdmin(currentUser.email === ADMIN_EMAIL);
      }
      setLoading(false);
    });
    
    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4285F4" />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <NavigationContainer>
      <StatusBar barStyle="dark-content" />
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {user ? (
          <Stack.Screen name="Dashboard">
            {props => <DashboardScreen {...props} user={user} />}
          </Stack.Screen>
        ) : (
          <Stack.Screen name="Login" component={LoginScreen} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#555',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loginCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 20,
    color: '#555',
    textAlign: 'center',
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  buttonGroup: {
    marginTop: 10,
  },
  primaryButton: {
    backgroundColor: '#4285F4',
    borderRadius: 5,
    padding: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  toggleButton: {
    marginTop: 15,
    alignItems: 'center',
  },
  toggleText: {
    color: '#4285F4',
    fontSize: 14,
  },
  header: {
    backgroundColor: '#4285F4',
    padding: 15,
    paddingTop: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  userInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: '#fff',
    fontSize: 16,
  },
  logoutButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  logoutText: {
    color: '#fff',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  section: {
    marginBottom: 20,
  },
  sectionSubtitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#555',
  },
  courseCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  courseTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  courseDetail: {
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
  },
  courseButton: {
    backgroundColor: '#4285F4',
    borderRadius: 4,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  courseButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyText: {
    textAlign: 'center',
    color: '#888',
    marginTop: 10,
    marginBottom: 20,
  },
});
