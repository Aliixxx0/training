import React, { useState } from 'react';
import { 
  View, 
  Text, 
  TextInput, 
  TouchableOpacity, 
  StyleSheet, 
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import { router } from 'expo-router';
import { auth, provider, database, testAuth } from '../firebaseConfig';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  AuthError
} from 'firebase/auth';
import { ref, get, set } from 'firebase/database';

// Define the admin email
const ADMIN_EMAIL = 'admin@training.com';

export default function LoginScreen() {
  const [data, setData] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [isLogin, setIsLogin] = useState(true);

  const handleInputChange = (name: string, value: string) => {
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleLogin = async () => {
    if (!data.email || !data.password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      console.log('Attempting login with:', data.email);
      
      // Check if the email is the admin email
      const isAdmin = data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      
      // First try with the test function for simplicity in testing
      try {
        const testResult = await testAuth(data.email, data.password);
        console.log('Test auth result:', testResult);
        
        if (testResult && testResult.success) {
          console.log('Test auth successful');
          
          // Use setTimeout to avoid navigation issues
          setTimeout(() => {
            if (isAdmin) {
              console.log('Navigating to admin panel...');
              router.navigate('/admin');
            } else {
              console.log('Navigating to dashboard...');
              router.navigate('/dashboard');
            }
            setLoading(false);
          }, 500);
          
          return; // Exit early
        }
      } catch (testErr) {
        console.log('Test auth failed, trying Firebase auth');
        // Continue to Firebase auth
      }
      
      // Try Firebase authentication if test auth failed
      try {
        const userCredential = await signInWithEmailAndPassword(auth, data.email, data.password);
        const user = userCredential.user;
        
        // Check if user is admin based on email or database role
        let userIsAdmin = isAdmin; // Default to email check
        
        // Also check database for admin role
        const userRef = ref(database, 'users/' + user.uid);
        const snapshot = await get(userRef);
        
        if (snapshot.exists()) {
          const userData = snapshot.val();
          // If database has admin flag, use it (overrides email check)
          if (userData.isAdmin !== undefined) {
            userIsAdmin = userData.isAdmin === true;
          } else {
            // Update admin status based on email
            await set(ref(database, 'users/' + user.uid), {
              ...userData,
              isAdmin: isAdmin
            });
          }
        } else {
          // Create user record if it doesn't exist
          await set(ref(database, 'users/' + user.uid), {
            email: user.email,
            uid: user.uid,
            isAdmin: isAdmin // Set admin status based on email
          });
        }
        
        // Use setTimeout to avoid navigation issues
        setTimeout(() => {
          if (userIsAdmin) {
            console.log('Navigating to admin panel...');
            router.navigate('/admin');
          } else {
            console.log('Navigating to dashboard...');
            router.navigate('/dashboard');
          }
          setLoading(false);
        }, 500);
        
      } catch (firebaseErr: any) {
        console.error('Firebase auth error:', firebaseErr);
        Alert.alert('Login Failed', 'Invalid email or password');
        setLoading(false);
      }
      
    } catch (err: any) {
      console.error('Login error:', err);
      Alert.alert('Login Failed', 'An unexpected error occurred');
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!data.email || !data.password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    // Check if trying to register with admin email
    if (data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      Alert.alert('Registration Error', 'This email is reserved. Please use a different email.');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password);
      const user = userCredential.user;
      
      // Save user data to database (default as regular user)
      await set(ref(database, 'users/' + user.uid), {
        email: user.email,
        uid: user.uid,
        isAdmin: false
      });
      
      // Delay navigation slightly
      setTimeout(() => {
        console.log('Account created, navigating to dashboard...');
        router.navigate('/dashboard');
        setLoading(false);
      }, 500);
      
    } catch (err: any) {
      const errorMessage = err?.message || 'An unknown error occurred';
      Alert.alert('Signup Failed', errorMessage);
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.loginCard}>
          <Text style={styles.title}>Training.com</Text>
          <Text style={styles.subtitle}>{isLogin ? 'Login' : 'Sign Up'}</Text>
          
          <View style={styles.formGroup}>
            <TextInput
              placeholder="Email"
              value={data.email}
              onChangeText={(text) => handleInputChange('email', text)}
              style={styles.input}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
          
          <View style={styles.formGroup}>
            <TextInput
              placeholder="Password"
              value={data.password}
              onChangeText={(text) => handleInputChange('password', text)}
              style={styles.input}
              secureTextEntry
            />
          </View>
          
          <View style={styles.buttonGroup}>
            {isLogin ? (
              <TouchableOpacity 
                style={styles.primaryButton} 
                onPress={handleLogin}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Login</Text>
                )}
              </TouchableOpacity>
            ) : (
              <TouchableOpacity 
                style={styles.primaryButton} 
                onPress={handleSignup}
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.buttonText}>Sign Up</Text>
                )}
              </TouchableOpacity>
            )}
          </View>
          
          <TouchableOpacity 
            style={styles.toggleButton} 
            onPress={() => setIsLogin(!isLogin)}
          >
            <Text style={styles.toggleText}>
              {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loginCard: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '100%',
    maxWidth: 400,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 20,
    color: '#555',
    textAlign: 'center',
    marginBottom: 20,
  },
  formGroup: {
    marginBottom: 15,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
  },
  buttonGroup: {
    marginTop: 10,
  },
  primaryButton: {
    backgroundColor: '#4285F4',
    borderRadius: 5,
    padding: 15,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  toggleButton: {
    marginTop: 15,
    alignItems: 'center',
  },
  toggleText: {
    color: '#4285F4',
    fontSize: 14,
  },
});