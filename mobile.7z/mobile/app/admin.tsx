import React, { useState, useEffect, ReactNode } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StatusBar,
  ScrollView
} from 'react-native';
import { signOut } from 'firebase/auth';
import { auth, database } from '../firebaseConfig';
import { ref, get, set } from 'firebase/database';
import { router } from 'expo-router';

// Define types
interface UserData {
  email: string;
  uid: string;
  id?: string;
  name?: string;
  isAdmin?: boolean;
}

interface Course {
  id: string;
  title: string;
  duration: string;
  level: string;
  students: number;
}

interface SectionHeaderProps {
  title: string;
  children: ReactNode;
  initialExpanded?: boolean;
}

export default function AdminScreen() {
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState<UserData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userData, setUserData] = useState<UserData | null>(null);
  
  // Dummy training data
  const trainingCourses: Course[] = [
    { id: '1', title: 'React Basics', duration: '8 weeks', level: 'Intermediate', students: 22 },
    { id: '2', title: 'Advanced CSS Techniques', duration: '3 weeks', level: 'Intermediate', students: 15 },
    { id: '3', title: 'Backend Development with Node.js', duration: '10 weeks', level: 'Advanced', students: 10 }
  ];

  useEffect(() => {
    // Check if current user is actually admin
    const checkAdmin = async () => {
      try {
        const user = auth.currentUser;
        
        if (!user) {
          console.log('No user logged in, redirecting to login');
          router.replace('/');
          return;
        }
        
        // Get user data from database
        const userRef = ref(database, 'users/' + user.uid);
        const snapshot = await get(userRef);
        
        if (snapshot.exists()) {
          const userDataFromDb = snapshot.val() as UserData;
          setUserData(userDataFromDb);
          
          // If not admin, redirect to dashboard
          if (!userDataFromDb.isAdmin && user.email !== 'admin@training.com') {
            console.log('User is not admin, redirecting to dashboard');
            router.replace('/dashboard');
          }
        } else {
          // No user data, check if email is admin@training.com
          if (user.email === 'admin@training.com') {
            // Create admin record
            await set(ref(database, 'users/' + user.uid), {
              email: user.email,
              uid: user.uid,
              isAdmin: true
            });
          } else {
            // Not admin, redirect to login
            console.log('No user data found, redirecting to login');
            router.replace('/');
          }
        }
      } catch (error) {
        console.error('Error checking admin status:', error);
        router.replace('/');
      }
    };
    
    checkAdmin();
    
    // Fetch users from the database
    const fetchUsers = async () => {
      try {
        const usersRef = ref(database, 'users');
        const snapshot = await get(usersRef);
        
        if (snapshot.exists()) {
          const usersData: UserData[] = [];
          snapshot.forEach((childSnapshot) => {
            usersData.push({
              id: childSnapshot.key,
              ...childSnapshot.val()
            } as UserData);
          });
          setUsers(usersData);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
        Alert.alert('Error', 'Failed to fetch users');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      router.replace('/');
    } catch (error: any) {
      console.error('Logout failed:', error);
      Alert.alert('Logout Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEditCourse = (course: Course) => {
    Alert.alert('Coming Soon', 'Edit functionality will be available in the next update.');
  };

  const handleDeleteCourse = (course: Course) => {
    Alert.alert(
      'Delete Course',
      `Are you sure you want to delete "${course.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => Alert.alert('Coming Soon', 'Delete functionality will be available in the next update.') }
      ]
    );
  };

  const handleAddCourse = () => {
    Alert.alert('Coming Soon', 'Add course functionality will be available in the next update.');
  };

  const handleViewUser = (user: UserData) => {
    Alert.alert('Coming Soon', 'View user details will be available in the next update.');
  };

  const handleRemoveUser = (user: UserData) => {
    Alert.alert(
      'Remove User',
      `Are you sure you want to remove "${user.email}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => Alert.alert('Coming Soon', 'Remove user functionality will be available in the next update.') }
      ]
    );
  };

  // Simple Collapsible component since we can't import the custom one
  const SectionHeader = ({ title, children, initialExpanded = true }: SectionHeaderProps) => {
    const [expanded, setExpanded] = useState(initialExpanded);
    
    return (
      <View style={styles.sectionContainer}>
        <TouchableOpacity 
          style={styles.sectionHeader}
          onPress={() => setExpanded(!expanded)}
        >
          <Text style={styles.sectionTitle}>{title}</Text>
          <Text>{expanded ? '▼' : '►'}</Text>
        </TouchableOpacity>
        {expanded && (
          <View style={styles.sectionContent}>
            {children}
          </View>
        )}
      </View>
    );
  };

  const renderCourseItem = ({ item }: { item: Course }) => (
    <View style={styles.cardItem}>
      <View style={styles.cardContent}>
        <Text style={styles.itemTitle}>{item.title}</Text>
        <Text style={styles.itemDetail}>Duration: {item.duration}</Text>
        <Text style={styles.itemDetail}>Level: {item.level}</Text>
        <Text style={styles.itemDetail}>Students: {item.students}</Text>
      </View>
      <View style={styles.cardActions}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.editButton]}
          onPress={() => handleEditCourse(item)}
        >
          <Text style={styles.actionButtonText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDeleteCourse(item)}
        >
          <Text style={styles.actionButtonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderUserItem = ({ item }: { item: UserData }) => (
    <View style={styles.cardItem}>
      <View style={styles.cardContent}>
        <Text style={styles.itemTitle}>{item.email}</Text>
        <Text style={styles.itemDetail}>Name: {item.name || 'N/A'}</Text>
        <Text style={styles.itemDetail}>ID: {item.uid || item.id}</Text>
        <Text style={styles.itemDetail}>Role: {item.isAdmin ? 'Admin' : 'User'}</Text>
      </View>
      <View style={styles.cardActions}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.viewButton]}
          onPress={() => handleViewUser(item)}
        >
          <Text style={styles.actionButtonText}>View</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleRemoveUser(item)}
        >
          <Text style={styles.actionButtonText}>Remove</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#4285F4" barStyle="light-content" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Training.com - Admin Panel</Text>
        <View style={styles.userInfo}>
          <Text style={styles.welcomeText}>
            Admin: {userData?.email || auth.currentUser?.email || 'Admin'}
          </Text>
          <TouchableOpacity 
            style={styles.logoutButton} 
            onPress={handleLogout}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.logoutText}>Logout</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content}>
        <SectionHeader title="Course Management">
          <FlatList
            data={trainingCourses}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            scrollEnabled={false}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No courses found.</Text>
            }
          />
          
          <TouchableOpacity 
            style={styles.addButton}
            onPress={handleAddCourse}
          >
            <Text style={styles.addButtonText}>Add New Course</Text>
          </TouchableOpacity>
        </SectionHeader>
        
        <SectionHeader title="User Management">
          {isLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#4285F4" />
              <Text style={styles.loadingText}>Loading users...</Text>
            </View>
          ) : (
            <FlatList
              data={users}
              renderItem={renderUserItem}
              keyExtractor={item => item.id || item.uid}
              scrollEnabled={false}
              ListEmptyComponent={
                <Text style={styles.emptyText}>No users found.</Text>
              }
            />
          )}
        </SectionHeader>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#4285F4',
    padding: 15,
    paddingTop: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  userInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: '#fff',
    fontSize: 16,
  },
  logoutButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  logoutText: {
    color: '#fff',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionContainer: {
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#f8f8f8',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  sectionContent: {
    padding: 15,
  },
  cardItem: {
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 6,
    marginBottom: 10,
    overflow: 'hidden',
  },
  cardContent: {
    padding: 12,
    backgroundColor: '#f9f9f9',
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  itemDetail: {
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
  },
  cardActions: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  editButton: {
    backgroundColor: '#f0f8ff',
  },
  viewButton: {
    backgroundColor: '#f0f8ff',
  },
  deleteButton: {
    backgroundColor: '#fff0f0',
  },
  addButton: {
    backgroundColor: '#4285F4',
    borderRadius: 4,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignSelf: 'flex-start',
    marginTop: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyText: {
    textAlign: 'center',
    color: '#888',
    padding: 15,
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
});