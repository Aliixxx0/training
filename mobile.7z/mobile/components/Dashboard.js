import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StatusBar
} from 'react-native';
import { signOut } from 'firebase/auth';
import { auth } from '../firebaseConfig';

const Dashboard = ({ user }) => {
  const [loading, setLoading] = useState(false);
  
  // Dummy training data - same as web app
  const trainingCourses = [
    { id: '1', title: 'Introduction to Web Development', duration: '4 weeks', level: 'Beginner', enrolled: true },
    { id: '2', title: 'JavaScript Fundamentals', duration: '6 weeks', level: 'Beginner', enrolled: true },
    { id: '3', title: 'React Basics', duration: '8 weeks', level: 'Intermediate', enrolled: false },
    { id: '4', title: 'Advanced CSS Techniques', duration: '3 weeks', level: 'Intermediate', enrolled: false },
    { id: '5', title: 'Backend Development with Node.js', duration: '10 weeks', level: 'Advanced', enrolled: false }
  ];

  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      setTimeout(() => {
        router.replace('/');
        setLoading(false);
      }, 500);
      // Navigation will be handled by the auth state listener in App.js
    } catch (error) {
      Alert.alert('Logout Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  const renderCourseItem = ({ item }) => (
    <View style={styles.courseCard}>
      <Text style={styles.courseTitle}>{item.title}</Text>
      <Text style={styles.courseDetail}>Duration: {item.duration}</Text>
      <Text style={styles.courseDetail}>Level: {item.level}</Text>
      <TouchableOpacity 
        style={styles.courseButton}
        onPress={() => Alert.alert('Coming Soon', 'This feature will be available in the next update.')}
      >
        <Text style={styles.courseButtonText}>
          {item.enrolled ? 'Continue Learning' : 'Join Now'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#4285F4" barStyle="light-content" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Training.com</Text>
        <View style={styles.userInfo}>
          <Text style={styles.welcomeText}>
            Welcome, {user?.displayName || user?.email || 'User'}
          </Text>
          <TouchableOpacity 
            style={styles.logoutButton} 
            onPress={handleLogout}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text style={styles.logoutText}>Logout</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.content}>
        <Text style={styles.sectionTitle}>My Training Dashboard</Text>
        
        <View style={styles.section}>
          <Text style={styles.sectionSubtitle}>My Enrolled Courses</Text>
          <FlatList
            data={trainingCourses.filter(course => course.enrolled)}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No enrolled courses found.</Text>
            }
          />
        </View>
        
        <View style={styles.section}>
          <Text style={styles.sectionSubtitle}>Available Courses</Text>
          <FlatList
            data={trainingCourses.filter(course => !course.enrolled)}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            ListEmptyComponent={
              <Text style={styles.emptyText}>No available courses found.</Text>
            }
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#4285F4',
    padding: 15,
    paddingTop: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  userInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: '#fff',
    fontSize: 16,
  },
  logoutButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  logoutText: {
    color: '#fff',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  section: {
    marginBottom: 20,
  },
  sectionSubtitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#555',
  },
  courseCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 15,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  courseTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  courseDetail: {
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
  },
  courseButton: {
    backgroundColor: '#4285F4',
    borderRadius: 4,
    paddingVertical: 8,
    paddingHorizontal: 12,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  courseButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyText: {
    textAlign: 'center',
    color: '#888',
    marginTop: 10,
    marginBottom: 20,
  },
});

export default Dashboard;
