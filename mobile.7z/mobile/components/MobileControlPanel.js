import React, { useState, useEffect } from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
  SafeAreaView,
  StatusBar,
  ScrollView
} from 'react-native';
import { signOut } from 'firebase/auth';
import { auth, database } from '../firebaseConfig';
import { ref, get } from 'firebase/database';

// Import your existing components
import { ThemedText } from './ui/ThemedText';
import { ThemedView } from './ThemedView';
import { IconSymbol } from './ui/IconSymbol';
import { Collapsible } from './ui/Collapsible';

const MobileControlPanel = ({ user }) => {
  const [loading, setLoading] = useState(false);
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Dummy training data - same structure as web app
  const trainingCourses = [
    { id: '1', title: 'React Basics', duration: '8 weeks', level: 'Intermediate', students: 22 },
    { id: '2', title: 'Advanced CSS Techniques', duration: '3 weeks', level: 'Intermediate', students: 15 },
    { id: '3', title: 'Backend Development with Node.js', duration: '10 weeks', level: 'Advanced', students: 10 }
  ];

  useEffect(() => {
    // Fetch users from the database
    const fetchUsers = async () => {
      try {
        const usersRef = ref(database, 'users');
        const snapshot = await get(usersRef);
        
        if (snapshot.exists()) {
          const usersData = [];
          snapshot.forEach((childSnapshot) => {
            usersData.push({
              id: childSnapshot.key,
              ...childSnapshot.val()
            });
          });
          setUsers(usersData);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
        Alert.alert('Error', 'Failed to fetch users');
      } finally {
        setIsLoading(false);
      }
    };

    fetchUsers();
  }, []);

  const handleLogout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      // Navigation will be handled by the auth state listener in App.js
    } catch (error) {
      Alert.alert('Logout Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEditCourse = (course) => {
    Alert.alert('Coming Soon', 'Edit functionality will be available in the next update.');
  };

  const handleDeleteCourse = (course) => {
    Alert.alert(
      'Delete Course',
      `Are you sure you want to delete "${course.title}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => Alert.alert('Coming Soon', 'Delete functionality will be available in the next update.') }
      ]
    );
  };

  const handleAddCourse = () => {
    Alert.alert('Coming Soon', 'Add course functionality will be available in the next update.');
  };

  const handleViewUser = (user) => {
    Alert.alert('Coming Soon', 'View user details will be available in the next update.');
  };

  const handleRemoveUser = (user) => {
    Alert.alert(
      'Remove User',
      `Are you sure you want to remove "${user.email}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Remove', style: 'destructive', onPress: () => Alert.alert('Coming Soon', 'Remove user functionality will be available in the next update.') }
      ]
    );
  };

  const renderCourseItem = ({ item }) => (
    <ThemedView style={styles.cardItem}>
      <ThemedView style={styles.cardContent}>
        <ThemedText type="defaultSemiBold">{item.title}</ThemedText>
        <ThemedText>Duration: {item.duration}</ThemedText>
        <ThemedText>Level: {item.level}</ThemedText>
        <ThemedText>Students: {item.students}</ThemedText>
      </ThemedView>
      <View style={styles.cardActions}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.editButton]}
          onPress={() => handleEditCourse(item)}
        >
          <ThemedText style={styles.actionButtonText}>Edit</ThemedText>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDeleteCourse(item)}
        >
          <ThemedText style={styles.actionButtonText}>Delete</ThemedText>
        </TouchableOpacity>
      </View>
    </ThemedView>
  );

  const renderUserItem = ({ item }) => (
    <ThemedView style={styles.cardItem}>
      <ThemedView style={styles.cardContent}>
        <ThemedText type="defaultSemiBold">{item.email}</ThemedText>
        <ThemedText>Name: {item.name || 'N/A'}</ThemedText>
        <ThemedText>ID: {item.uid || item.id}</ThemedText>
      </ThemedView>
      <View style={styles.cardActions}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.viewButton]}
          onPress={() => handleViewUser(item)}
        >
          <ThemedText style={styles.actionButtonText}>View</ThemedText>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleRemoveUser(item)}
        >
          <ThemedText style={styles.actionButtonText}>Remove</ThemedText>
        </TouchableOpacity>
      </View>
    </ThemedView>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor="#4285F4" barStyle="light-content" />
      
      <View style={styles.header}>
        <ThemedText style={styles.headerTitle}>Training.com - Admin Panel</ThemedText>
        <View style={styles.userInfo}>
          <ThemedText style={styles.welcomeText}>
            Admin: {user?.email || 'Admin'}
          </ThemedText>
          <TouchableOpacity 
            style={styles.logoutButton} 
            onPress={handleLogout}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <ThemedText style={styles.logoutText}>Logout</ThemedText>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content}>
        <Collapsible title="Course Management">
          <FlatList
            data={trainingCourses}
            renderItem={renderCourseItem}
            keyExtractor={item => item.id}
            scrollEnabled={false}
            ListEmptyComponent={
              <ThemedText style={styles.emptyText}>No courses found.</ThemedText>
            }
          />
          
          <TouchableOpacity 
            style={styles.addButton}
            onPress={handleAddCourse}
          >
            <ThemedText style={styles.addButtonText}>Add New Course</ThemedText>
          </TouchableOpacity>
        </Collapsible>
        
        <Collapsible title="User Management">
          {isLoading ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#4285F4" />
              <ThemedText style={styles.loadingText}>Loading users...</ThemedText>
            </View>
          ) : (
            <FlatList
              data={users}
              renderItem={renderUserItem}
              keyExtractor={item => item.id || item.uid}
              scrollEnabled={false}
              ListEmptyComponent={
                <ThemedText style={styles.emptyText}>No users found.</ThemedText>
              }
            />
          )}
        </Collapsible>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#4285F4',
    padding: 15,
    paddingTop: 20,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
  },
  userInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: '#fff',
    fontSize: 16,
  },
  logoutButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  logoutText: {
    color: '#fff',
    fontSize: 14,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  cardItem: {
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 6,
    marginBottom: 10,
    overflow: 'hidden',
  },
  cardContent: {
    padding: 12,
    backgroundColor: '#f9f9f9',
  },
  cardActions: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  actionButton: {
    flex: 1,
    paddingVertical: 8,
    alignItems: 'center',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
  },
  editButton: {
    backgroundColor: '#f0f8ff',
  },
  viewButton: {
    backgroundColor: '#f0f8ff',
  },
  deleteButton: {
    backgroundColor: '#fff0f0',
  },
  addButton: {
    backgroundColor: '#4285F4',
    borderRadius: 4,
    paddingVertical: 10,
    paddingHorizontal: 15,
    alignSelf: 'flex-start',
    marginTop: 10,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '500',
  },
  emptyText: {
    textAlign: 'center',
    color: '#888',
    padding: 15,
  },
  loadingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#666',
    fontSize: 16,
  },
});

export default MobileControlPanel;