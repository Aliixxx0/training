const userModel = require('../models/userModel');

// Get dashboard data based on user role
const getDashboardData = async (req, res) => {
  try {
    const { uid, email } = req.user;
    
    // Get user data from database
    const userData = await userModel.getUserByUid(uid);
    
    // Check if the user is admin
    const isAdmin = email === 'admin@training.com' || (userData && userData.role === 'admin');
    
    if (isAdmin) {
      // Return admin dashboard data
      return res.status(200).json({
        success: true,
        role: 'admin',
        user: {
          uid,
          email,
          ...userData
        },
        data: {
          totalUsers: 45,
          activeUsers: 28,
          courses: [
            { id: 1, title: 'Introduction to Web Development', students: 45, completion: '78%' },
            { id: 2, title: 'JavaScript Fundamentals', students: 38, completion: '65%' },
            { id: 3, title: 'React Basics', students: 22, completion: '42%' },
            { id: 4, title: 'Advanced CSS Techniques', students: 15, completion: '30%' },
            { id: 5, title: 'Backend Development with Node.js', students: 10, completion: '25%' }
          ],
          recentActivity: [
            { type: 'enrollment', user: 'john.doe@example.com', course: 'React Basics', date: '2025-04-15T10:30:00Z' },
            { type: 'completion', user: 'jane.smith@example.com', course: 'JavaScript Fundamentals', date: '2025-04-14T14:45:00Z' },
            { type: 'enrollment', user: 'mike.brown@example.com', course: 'Advanced CSS Techniques', date: '2025-04-13T09:15:00Z' }
          ]
        }
      });
    } else {
      // Return regular user dashboard data
      return res.status(200).json({
        success: true,
        role: 'user',
        user: {
          uid,
          email,
          ...userData
        },
        data: {
          enrolledCourses: [
            { id: 1, title: 'Introduction to Web Development', progress: '65%', nextLesson: 'CSS Layouts', dueDate: '2025-04-21T00:00:00Z' },
            { id: 2, title: 'JavaScript Fundamentals', progress: '30%', nextLesson: 'Functions and Scope', dueDate: '2025-04-19T00:00:00Z' }
          ],
          recommendedCourses: [
            { id: 3, title: 'React Basics', duration: '8 weeks', level: 'Intermediate' },
            { id: 4, title: 'Advanced CSS Techniques', duration: '3 weeks', level: 'Intermediate' },
            { id: 5, title: 'Backend Development with Node.js', duration: '10 weeks', level: 'Advanced' }
          ],
          achievements: [
            { id: 1, title: 'First Login', date: '2025-03-10T00:00:00Z' },
            { id: 2, title: 'Completed First Lesson', date: '2025-03-12T00:00:00Z' }
          ]
        }
      });
    }
  } catch (error) {
    console.error('Error getting dashboard data:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve dashboard data',
      error: error.message
    });
  }
};

// Admin only - Get all users for admin panel
const getAllUsers = async (req, res) => {
  try {
    const users = await userModel.getAllUsers();
    
    return res.status(200).json({
      success: true,
      users
    });
  } catch (error) {
    console.error('Error getting all users:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to retrieve users',
      error: error.message
    });
  }
};

// Admin only - Update user role
const updateUserRole = async (req, res) => {
  try {
    const { uid, role } = req.body;
    
    if (!uid || !role) {
      return res.status(400).json({
        success: false,
        message: 'UID and role are required'
      });
    }
    
    if (role !== 'admin' && role !== 'user') {
      return res.status(400).json({
        success: false,
        message: 'Role must be either "admin" or "user"'
      });
    }
    
    await userModel.setUserRole(uid, role);
    
    return res.status(200).json({
      success: true,
      message: `User role updated to ${role}`
    });
  } catch (error) {
    console.error('Error updating user role:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to update user role',
      error: error.message
    });
  }
};

module.exports = {
  getDashboardData,
  getAllUsers,
  updateUserRole
};