const express = require('express');
const router = express.Router();
const { authenticateUser, isAdmin } = require('../middleware/authMiddleware');
const dashboardController = require('../controllers/dashboardController');

// Public routes (no authentication required)
router.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Server is healthy' });
});

// Protected routes (authentication required)
// Dashboard route that returns different data based on user role
router.get('/dashboard', authenticateUser, dashboardController.getDashboardData);

// Admin-only routes
router.get('/users', authenticateUser, isAdmin, dashboardController.getAllUsers);
router.put('/users/role', authenticateUser, isAdmin, dashboardController.updateUserRole);

module.exports = router;