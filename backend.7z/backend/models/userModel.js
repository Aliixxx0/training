const { admin } = require('../config/firebase-config');
const database = admin.database();

// Reference to the users in Firebase Realtime Database
const usersRef = database.ref('users');

// Get user by uid
const getUserByUid = async (uid) => {
  try {
    const snapshot = await usersRef.child(uid).once('value');
    return snapshot.val();
  } catch (error) {
    console.error('Error getting user:', error);
    throw error;
  }
};

// Create or update user
const createOrUpdateUser = async (uid, userData) => {
  try {
    await usersRef.child(uid).update({
      ...userData,
      updatedAt: new Date().toISOString()
    });
    return { success: true };
  } catch (error) {
    console.error('Error creating/updating user:', error);
    throw error;
  }
};

// Get all users
const getAllUsers = async () => {
  try {
    const snapshot = await usersRef.once('value');
    const users = [];
    
    snapshot.forEach((childSnapshot) => {
      users.push({
        uid: childSnapshot.key,
        ...childSnapshot.val()
      });
    });
    
    return users;
  } catch (error) {
    console.error('Error getting all users:', error);
    throw error;
  }
};

// Set user role
const setUserRole = async (uid, role) => {
  try {
    await usersRef.child(uid).update({
      role,
      updatedAt: new Date().toISOString()
    });
    
    // Optional: Set custom claims for role-based auth
    await admin.auth().setCustomUserClaims(uid, { [role]: true });
    
    return { success: true };
  } catch (error) {
    console.error('Error setting user role:', error);
    throw error;
  }
};

module.exports = {
  getUserByUid,
  createOrUpdateUser,
  getAllUsers,
  setUserRole
};