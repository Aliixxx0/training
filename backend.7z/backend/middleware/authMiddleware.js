const { admin } = require('../config/firebase-config');

// Firebase auth middleware
const authenticateUser = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false, 
        message: 'Unauthorized: No token provided' 
      });
    }

    const idToken = authHeader.split('Bearer ')[1];
    
    // Verify the token
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    if (!decodedToken) {
      return res.status(401).json({ 
        success: false, 
        message: 'Unauthorized: Invalid token' 
      });
    }

    // Add the user info to the request
    req.user = decodedToken;
    
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    return res.status(401).json({ 
      success: false, 
      message: 'Unauthorized: Invalid token',
      error: error.message 
    });
  }
};

// Admin authorization middleware
const isAdmin = (req, res, next) => {
  // Check if the user has admin custom claim or email is admin@training.com
  if (req.user && (req.user.admin === true || req.user.email === 'admin@training.com')) {
    next();
  } else {
    return res.status(403).json({ 
      success: false, 
      message: 'Forbidden: Admin access required' 
    });
  }
};

module.exports = { authenticateUser, isAdmin };